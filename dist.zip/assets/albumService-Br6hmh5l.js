import{c as a}from"./index-BvDgMvcc.js";const r={async getAlbums(){return(await a.get("/albums")).data},async getAlbum(s){return(await a.get(`/albums/${s}`)).data}};export{r as a};
