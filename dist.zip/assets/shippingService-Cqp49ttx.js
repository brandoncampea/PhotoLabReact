import{c as n}from"./index-CuhRrxv4.js";const p={async getConfig(){return(await n.get("/shipping/config")).data},async updateConfig(s){return(await n.put("/shipping/config",s)).data}};export{p as s};
